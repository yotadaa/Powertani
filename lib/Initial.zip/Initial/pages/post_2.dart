import 'package:flutter/material.dart';

class MyPost2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.pink[300],
    );
  }
}
