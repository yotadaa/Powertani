import 'package:flutter/material.dart';

class MyPost3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.deepPurple[300],
    );
  }
}
